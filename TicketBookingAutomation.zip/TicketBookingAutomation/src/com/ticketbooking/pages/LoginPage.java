package com.ticketbooking.pages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;

    // Locators
    private By username = By.name("userName");
    private By password = By.name("password");
    private By loginButton = By.name("submit");

    // Constructor
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Action method
    public void login(String user, String pass) {
        driver.findElement(username).sendKeys(user);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(loginButton).click();
    }
}
