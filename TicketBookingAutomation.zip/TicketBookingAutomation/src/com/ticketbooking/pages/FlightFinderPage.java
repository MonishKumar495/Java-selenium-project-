package com.ticketbooking.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FlightFinderPage {

    WebDriver driver;

    public FlightFinderPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectTripType() {
        driver.findElement(By.xpath("//input[@value='roundtrip']")).click();
    }

    public void clickContinue() {
        driver.findElement(By.name("findFlights")).click();
    }

    public void searchFlights(String fromPort, String toPort) {
        driver.findElement(By.name("fromPort")).sendKeys(fromPort);
        driver.findElement(By.name("toPort")).sendKeys(toPort);
        clickContinue();
    }
}
