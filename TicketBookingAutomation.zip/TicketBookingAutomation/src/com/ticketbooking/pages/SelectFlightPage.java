package com.ticketbooking.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SelectFlightPage {
    WebDriver driver;

    private By departFlight = By.name("outFlight");
    private By returnFlight = By.name("inFlight");
    private By reserveButton = By.name("reserveFlights");

    public SelectFlightPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectFlightOptions() {
        driver.findElements(departFlight).get(0).click();
        driver.findElements(returnFlight).get(0).click();
        driver.findElement(reserveButton).click();
    }
}
