package com.ticketbooking.test;

import com.ticketbooking.pages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class LoginTest {

    WebDriver driver;
    LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver",
                "D:\\Java CapGemini\\chromedriver-win64\\chromedriver.exe");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://demo.guru99.com/test/newtours/");

        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLogin() {

        loginPage.login("tutorial", "tutorial");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // ✅ MOST RELIABLE validation for this site
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'Login Successfully')]")));

        boolean loginSuccess =
                driver.getPageSource().contains("Login Successfully");

        Assert.assertTrue(loginSuccess,
                "Login failed - success message not displayed");

        System.out.println("✅ Login Test PASSED");
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
