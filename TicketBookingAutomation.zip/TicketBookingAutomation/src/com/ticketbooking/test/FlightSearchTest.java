package com.ticketbooking.test;

import com.ticketbooking.pages.FlightFinderPage;
import com.ticketbooking.pages.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.HashMap;
import java.util.Map;

public class FlightSearchTest {

    WebDriver driver;
    LoginPage loginPage;
    FlightFinderPage flightFinderPage;

    @BeforeMethod
    public void setup() {

        System.setProperty(
                "webdriver.chrome.driver",
                "D:\\Java CapGemini\\chromedriver-win64\\chromedriver.exe"
        );

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--disable-infobars");
        options.addArguments("--disable-extensions");
        options.addArguments("--start-maximized");
        options.addArguments("--remote-allow-origins=*");

        Map<String, Object> prefs = new HashMap<>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);

        options.setExperimentalOption("prefs", prefs);
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("https://demo.guru99.com/test/newtours/");

        loginPage = new LoginPage(driver);
        flightFinderPage = new FlightFinderPage(driver);
    }

    @Test
    public void testFlightSearch() {

        // Login
        loginPage.login("mercury", "mercury");

        Assert.assertTrue(
                driver.getTitle().toLowerCase().contains("mercury tours"),
                "Login failed"
        );

        // Navigate to flight finder page
        driver.get("https://demo.guru99.com/test/newtours/reservation.php");

        Assert.assertTrue(
                driver.getTitle().toLowerCase().contains("find a flight"),
                "Not on flight finder page"
        );

        // Search flight
        flightFinderPage.selectTripType();
        flightFinderPage.searchFlights("London", "New York");
    }

    // @AfterMethod
    // public void tearDown() {
    //     driver.quit();
    // }
}
