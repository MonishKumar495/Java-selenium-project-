package com.ticketbooking.test;

import com.ticketbooking.pages.FlightFinderPage;
import com.ticketbooking.pages.LoginPage;
import com.ticketbooking.pages.SelectFlightPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import java.time.Duration;

public class SelectFlightTest {
    WebDriver driver;
    LoginPage loginPage;
    FlightFinderPage flightFinderPage;
    SelectFlightPage selectFlightPage;

    @BeforeMethod
    public void setUp() {
    	System.setProperty(
    		    "webdriver.chrome.driver",
    		    "D:\\Java CapGemini\\chromedriver-win64\\chromedriver.exe"
    		);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://demo.guru99.com/test/newtours/");

        loginPage = new LoginPage(driver);
        loginPage.login("tutorial", "tutorial");

        flightFinderPage = new FlightFinderPage(driver);
        flightFinderPage.searchFlights("New York", "Paris");

        selectFlightPage = new SelectFlightPage(driver);
    }

    @Test
    public void selectFlightTest() {
        selectFlightPage.selectFlightOptions();
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
